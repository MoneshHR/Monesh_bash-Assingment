import socket
import datetime

# Simple service mapping
services = {
    21: "FTP",
    22: "SSH",
    80: "HTTP",
    443: "HTTPS"
}

# Simple vulnerability database (hardcoded)
vulnerabilities = {
    "FTP": "Anonymous login may be enabled",
    "SSH": "Check for weak passwords or outdated version",
    "HTTP": "Possible XSS or outdated web server",
    "HTTPS": "Check SSL/TLS configuration"
}

def scan_port(target, port):
    s = socket.socket()
    s.settimeout(1)
    result = s.connect_ex((target, port))
    s.close()
    return result == 0

def generate_report(target, results):
    filename = "security_report.html"
    
    with open(filename, "w") as f:
        f.write(f"""
        <html>
        <head>
            <title>Security Audit Report</title>
            <style>
                body {{ font-family: Arial; }}
                table {{ border-collapse: collapse; width: 80%; }}
                th, td {{ border: 1px solid black; padding: 10px; }}
                th {{ background-color: #f2f2f2; }}
            </style>
        </head>
        <body>
            <h2>Security Audit Report</h2>
            <p><b>Target:</b> {target}</p>
            <p><b>Date:</b> {datetime.datetime.now()}</p>

            <table>
                <tr>
                    <th>Port</th>
                    <th>Status</th>
                    <th>Service</th>
                    <th>Potential Vulnerability</th>
                </tr>
        """)

        for port, status in results.items():
            service = services.get(port, "Unknown")
            vuln = vulnerabilities.get(service, "None")
            
            f.write(f"""
                <tr>
                    <td>{port}</td>
                    <td>{'OPEN' if status else 'CLOSED'}</td>
                    <td>{service}</td>
                    <td>{vuln if status else '-'}</td>
                </tr>
            """)

        f.write("""
            </table>
        </body>
        </html>
        """)

    print(f"\nReport generated: {filename}")

def main():
    target = input("Enter target IP: ")
    ports = [21, 22, 80, 443]

    print(f"\nScanning {target}...\n")

    results = {}

    for port in ports:
        is_open = scan_port(target, port)
        results[port] = is_open
        
        if is_open:
            print(f"Port {port}: OPEN")
        else:
            print(f"Port {port}: CLOSED")

    generate_report(target, results)

if __name__ == "__main__":
    main()
