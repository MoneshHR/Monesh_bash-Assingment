#include <stdio.h>
#include <string.h>

int main() {
    char buffer[16];   // Buffer of size 16
    char input[100];   // Larger input buffer

    printf("Enter some text: ");
    scanf("%s", input);   // Take user input

    // Unsafe copy (can cause buffer overflow)
    strcpy(buffer, input);

    printf("Buffer contains: %s\n", buffer);

    return 0;
}

/*
==========================
ANSWERS
==========================

1) What happens with long input?

If the user enters more than 16 characters (e.g., 30+ characters),
the strcpy() function copies all data into the buffer without checking size.

This causes a BUFFER OVERFLOW:
- Extra data overwrites adjacent memory
- Program may crash (segmentation fault)
- Output may become corrupted

--------------------------------------------------

2) Why is this dangerous?

Buffer overflow is dangerous because:
- It can crash the program
- It can overwrite important memory
- Attackers can exploit it to execute malicious code
- It is a common security vulnerability in C programs

--------------------------------------------------

3) How would you fix it?

Use safer alternatives that limit input size:

Option 1: Use strncpy()
    strncpy(buffer, input, sizeof(buffer) - 1);
    buffer[15] = '\0';

Option 2: Use fgets() instead of scanf
    fgets(input, sizeof(input), stdin);

Option 3: Validate input length before copying
    if (strlen(input) < sizeof(buffer)) {
        strcpy(buffer, input);
    }

These methods prevent writing beyond buffer limits.

==========================
TESTING
==========================

Normal input:
    hello
    → Works correctly

Long input (30+ chars):
    aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
    → May crash or behave unexpectedly
*/
