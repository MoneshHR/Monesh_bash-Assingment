#include <stdio.h>

int main() {
    int port = 80;
    int *ptr = &port;

    printf("%d\n", port);
    printf("%d\n", *ptr);

    *ptr = 443;

    printf("%d\n", port);

    return 0;
}
