NAME: Monesh H R
ROLL NUMBER: [Enter Your Roll Number]

---

PROJECT TITLE:
Cybersecurity Lab Assignment
----------------------------

DESCRIPTION:
This project includes multiple cybersecurity tasks such as network analysis, port scanning, Nmap usage, XSS testing, keylogging demonstration, and a security audit tool.

---

FILES INCLUDED:

1. buffer_test.c

   * Demonstrates buffer overflow vulnerability

2. c_port_scanner.c

   * Scans common ports using C sockets

3. security_audit.py

   * Python tool for port scanning and HTML report generation

4. http-server-info.nse

   * NSE script to extract HTTP server information

5. keylogger.html

   * Demonstrates keylogging using JavaScript

6. section6_xss.pdf

   * Contains XSS payload testing with screenshots and explanations

7. security_report.html

   * Sample output report generated from security_audit.py

---

TOOLS USED:

* Python
* C Programming
* Nmap
* OWASP Juice Shop
* Visual Studio Code

---

NOTES:

* All activities were performed in a safe and controlled environment
* Only authorized targets were used (e.g., scanme.nmap.org and Juice Shop)
* This project is for educational purposes only

---

AUTHOR DECLARATION:

I hereby declare that this work is done by me for academic purposes and follows ethical cybersecurity practices.

---
