description = [[
Retrieves basic HTTP server information:
- HTTP status code
- Server header
- Page title
]]

author = "Your Name"
license = "Same as Nmap"
categories = {"default", "safe"}

-- Load required libraries
local http = require "http"
local shortport = require "shortport"
local stdnse = require "stdnse"

-- Run only on HTTP ports
portrule = shortport.port_or_service({80, 8080}, {"http"})

action = function(host, port)
    -- Make HTTP request to root page
    local response = http.get(host, port, "/")

    if not response then
        return "No response received"
    end

    -- Extract HTTP status code
    local status = response.status or "Unknown"

    -- Extract Server header
    local server = response.header and response.header["server"] or "Not found"

    -- Extract Page title
    local title = "Not found"
    if response.body then
        title = string.match(response.body, "<title>(.-)</title>") or "Not found"
    end

    -- Format output
    local result = {}
    result[#result+1] = "Status Code: " .. status
    result[#result+1] = "Server: " .. server
    result[#result+1] = "Page Title: " .. title

    return stdnse.format_output(true, result)
end
