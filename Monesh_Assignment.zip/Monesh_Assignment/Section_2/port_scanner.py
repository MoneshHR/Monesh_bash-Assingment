import socket
import time

target = input("Enter IP: ")
ports = [21, 22, 80, 443, 3306]

start = time.time()

for port in ports:
    s = socket.socket()
    s.settimeout(1)
    result = s.connect_ex((target, port))
    
    if result == 0:
        print(f"Port {port}: OPEN")
    else:
        print(f"Port {port}: CLOSED")
    
    s.close()

print("Scan completed in", time.time() - start)
